/**
 * Seed script for the Preschool Student Management System.
 * Imports 48 students from /home/z/my-project/upload/Preschool student data.json
 * then generates sample programs, enrollments, fees, attendance, activities,
 * health alerts, and staff records to demonstrate the full system.
 *
 * Run with:  bun run /home/z/my-project/scripts/seed.ts
 */
import { PrismaClient } from '@prisma/client'
import fs from 'fs'

const db = new PrismaClient()

type RawStudent = {
  id: string
  indexNo: string
  fullName: string
  gender: string
  dob: string
  admissionDate: string
  enrolledPrograms: string[]
  ageGroup: string
  religion: string
  nationality: string
  previous_school: string
  guardians: { name: string; phone: string; address: string; relationship: string }[]
}

const PROGRAMS = [
  { code: 'PRESCHOOL', name: 'Preschool', description: 'Core preschool academic program', monthlyFee: 4500, capacity: 25, color: 'emerald' },
  { code: 'Daycare',   name: 'Daycare',   description: 'Full-day childcare service',     monthlyFee: 8000, capacity: 20, color: 'amber'   },
  { code: 'IT',        name: 'IT Basics', description: 'Introductory computing for kids', monthlyFee: 2500, capacity: 15, color: 'violet'  },
  { code: 'Elocution', name: 'Elocution', description: 'Speech & language development',  monthlyFee: 2000, capacity: 15, color: 'rose'    },
  { code: 'Dancing',   name: 'Dancing',   description: 'Movement & creative dance',       monthlyFee: 2000, capacity: 15, color: 'cyan'    },
]

const STAFF = [
  { staffCode: 'A001', name: 'Anjali Perera',     email: 'anjali@preschool.lk',  phone: '0771234567', role: 'ADMIN',    assignedClass: null,   assignedPrograms: 'ALL' },
  { staffCode: 'T001', name: 'Kumari Silva',      email: 'kumari@preschool.lk',  phone: '0772345678', role: 'TEACHER',  assignedClass: '2-3',  assignedPrograms: 'PRESCHOOL,Daycare' },
  { staffCode: 'T002', name: 'Nadeesha Fernando', email: 'nadeesha@preschool.lk',phone: '0773456789', role: 'TEACHER',  assignedClass: '3-4',  assignedPrograms: 'PRESCHOOL,Elocution' },
  { staffCode: 'T003', name: 'Ruwan Jayasuriya',  email: 'ruwan@preschool.lk',   phone: '0774567890', role: 'TEACHER',  assignedClass: '4-5',  assignedPrograms: 'PRESCHOOL,IT,Dancing' },
  { staffCode: 'F001', name: 'Saman Bandara',     email: 'saman@preschool.lk',   phone: '0775678901', role: 'FINANCE',  assignedClass: null,   assignedPrograms: 'ALL' },
  { staffCode: 'K001', name: 'Kiosk Console',     email: 'kiosk@preschool.lk',   phone: null,         role: 'KIOSK',    assignedClass: null,   assignedPrograms: 'ALL' },
]

const HEALTH_TEMPLATES = [
  { type: 'ALLERGY', severity: 'HIGH', desc: 'Peanut allergy — strictly avoid peanuts and peanut-based foods.' },
  { type: 'ALLERGY', severity: 'MEDIUM', desc: 'Lactose intolerance — provide lactose-free milk alternatives.' },
  { type: 'CONDITION', severity: 'LOW', desc: 'Mild asthma — keep inhaler in first-aid cabinet.' },
  { type: 'MEDICATION', severity: 'MEDIUM', desc: 'Requires vitamin supplement after lunch.' },
  { type: 'IMMUNIZATION', severity: 'LOW', desc: 'All age-appropriate immunizations on file (updated).' },
  { type: 'ALLERGY', severity: 'LOW', desc: 'Seasonal pollen sensitivity — keep windows closed on high-pollen days.' },
]

const ACTIVITY_TEMPLATES = [
  { category: 'MEAL',     title: 'Morning Snack',     description: 'Ate rice, vegetables, and fruit. Finished full portion.',       rating: 5 },
  { category: 'MEAL',     title: 'Lunch',             description: 'Ate most of the lunch. Left some rice.',                       rating: 4 },
  { category: 'NAP',      title: 'Nap Time',           description: 'Slept for 90 minutes. Woke up calm.',                          rating: 5 },
  { category: 'ACTIVITY', title: 'Art & Craft',        description: 'Painted a flower. Engaged and focused.',                      rating: 5 },
  { category: 'ACTIVITY', title: 'Outdoor Play',        description: 'Participated in group games.',                                rating: 4 },
  { category: 'BEHAVIOUR',title: 'Sharing Practice',    description: 'Shared toys well with peers today.',                          rating: 5 },
  { category: 'MOOD',     title: 'Mood Check',          description: 'Happy and energetic throughout the day.',                     rating: 5 },
  { category: 'INCIDENT', title: 'Minor Fall',         description: 'Slipped during play, no injury. Comforted within 5 minutes.', rating: 3 },
]

function randomChoice<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)] }
function randomInt(min: number, max: number) { return Math.floor(Math.random() * (max - min + 1)) + min }
function daysAgo(n: number): Date { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - n); return d }
function startOfMonth(year: number, month: number): Date { return new Date(Date.UTC(year, month, 1)) }

async function main() {
  console.log('🌱 Starting seed...')

  // Clean slate
  await db.healthAlert.deleteMany()
  await db.dailyActivity.deleteMany()
  await db.fee.deleteMany()
  await db.attendanceLog.deleteMany()
  await db.enrollment.deleteMany()
  await db.guardian.deleteMany()
  await db.student.deleteMany()
  await db.staff.deleteMany()
  await db.program.deleteMany()
  await db.setting.deleteMany()
  console.log('  ✓ Cleared all tables')

  // Programs
  const programMap: Record<string, string> = {}
  for (const p of PROGRAMS) {
    const created = await db.program.create({ data: { ...p } })
    programMap[p.code] = created.id
  }
  console.log(`  ✓ Created ${PROGRAMS.length} programs`)

  // Staff
  for (const s of STAFF) {
    await db.staff.create({ data: s })
  }
  console.log(`  ✓ Created ${STAFF.length} staff`)

  // Load raw students
  const rawPath = '/home/z/my-project/upload/Preschool student data.json'
  const raw: RawStudent[] = JSON.parse(fs.readFileSync(rawPath, 'utf-8'))
  console.log(`  ✓ Loaded ${raw.length} raw students from JSON`)

  let studentCount = 0
  let guardianCount = 0
  let enrollmentCount = 0

  for (const r of raw) {
    const student = await db.student.create({
      data: {
        studentCode:   r.id,
        indexNo:       r.indexNo,
        fullName:      r.fullName,
        gender:        r.gender,
        dob:           new Date(r.dob),
        admissionDate: new Date(r.admissionDate),
        ageGroup:      r.ageGroup,
        religion:      r.religion,
        nationality:   r.nationality,
        previousSchool:r.previous_school,
        status:        'ACTIVE',
      },
    })
    studentCount++

    for (const g of r.guardians) {
      await db.guardian.create({
        data: {
          studentId: student.id,
          name: g.name,
          phone: g.phone,
          address: g.address,
          relationship: g.relationship,
          emergencyContact: true,
        },
      })
      guardianCount++
    }

    for (const code of r.enrolledPrograms) {
      const pid = programMap[code]
      if (!pid) continue
      await db.enrollment.create({
        data: {
          studentId: student.id,
          programId: pid,
          enrolledOn: new Date(r.admissionDate),
          status: 'ACTIVE',
        },
      })
      enrollmentCount++
    }

    // Add 1-2 health alerts to ~40% of students
    if (Math.random() < 0.4) {
      const t = randomChoice(HEALTH_TEMPLATES)
      await db.healthAlert.create({
        data: { studentId: student.id, type: t.type, severity: t.severity, description: t.desc, active: true },
      })
    }
  }

  console.log(`  ✓ Created ${studentCount} students, ${guardianCount} guardians, ${enrollmentCount} enrollments`)

  // Fees for the current and last month for every enrollment
  const now = new Date()
  const thisMonthDate = startOfMonth(now.getFullYear(), now.getMonth())
  const lastMonthDate = startOfMonth(now.getFullYear(), now.getMonth() - 1)
  const nextMonthDate = startOfMonth(now.getFullYear(), now.getMonth() + 1)

  const enrollments = await db.enrollment.findMany({ include: { program: true } })
  let feeCount = 0
  for (const e of enrollments) {
    for (const periodDate of [lastMonthDate, thisMonthDate, nextMonthDate]) {
      const status = randomChoice(['PENDING', 'PENDING', 'PAID', 'PARTIAL', 'OVERDUE'])
      const amount = e.program.monthlyFee
      const paidAmount =
        status === 'PAID' ? amount :
        status === 'PARTIAL' ? Math.floor(amount * 0.5) : 0
      const paidAt = status === 'PAID' || status === 'PARTIAL' ? daysAgo(randomInt(0, 25)) : null
      const ym = `${periodDate.getFullYear()}-${String(periodDate.getMonth() + 1).padStart(2, '0')}`
      const due = new Date(periodDate)
      due.setDate(due.getDate() + 10)
      await db.fee.create({
        data: {
          studentId: e.studentId,
          programId: e.programId,
          amount,
          paidAmount,
          currency: 'LKR',
          period: ym,
          dueDate: due,
          status,
          method: paidAt ? randomChoice(['CASH', 'CARD', 'BANK', 'ONLINE']) : null,
          paidAt,
        },
      })
      feeCount++
    }
  }
  console.log(`  ✓ Created ${feeCount} fee records`)

  // Attendance — last 30 days for each student
  const students = await db.student.findMany()
  let attendanceCount = 0
  let activityCount = 0
  for (const s of students) {
    for (let i = 0; i < 30; i++) {
      const day = daysAgo(i)
      const weekday = day.getDay()
      if (weekday === 0 || weekday === 6) continue // skip weekends
      // 85% attendance rate
      const isPresent = Math.random() < 0.85
      if (isPresent) {
        const checkIn = new Date(day)
        checkIn.setHours(8, randomInt(0, 45), 0, 0)
        const checkOut = new Date(day)
        checkOut.setHours(15, randomInt(0, 45), 0, 0)
        await db.attendanceLog.create({
          data: {
            studentId: s.id,
            date: day,
            checkInTime: checkIn,
            checkOutTime: checkOut,
            method: randomChoice(['MANUAL', 'QR', 'RFID', 'KIOSK']),
            status: randomChoice(['PRESENT', 'PRESENT', 'PRESENT', 'LATE']),
            recordedBy: randomChoice(['T001', 'T002', 'T003', 'K001']),
          },
        })
        attendanceCount++
      } else {
        await db.attendanceLog.create({
          data: { studentId: s.id, date: day, status: 'ABSENT', method: 'MANUAL', recordedBy: 'T001' },
        })
        attendanceCount++
      }

      // Add 2-3 daily activities for the last 7 days for present students
      if (i < 7 && isPresent) {
        const samples = ACTIVITY_TEMPLATES.slice().sort(() => Math.random() - 0.5).slice(0, randomInt(2, 3))
        for (const a of samples) {
          await db.dailyActivity.create({
            data: {
              studentId: s.id,
              date: day,
              category: a.category,
              title: a.title,
              description: a.description,
              rating: a.rating,
              recordedBy: randomChoice(['T001', 'T002', 'T003']),
            },
          })
          activityCount++
        }
      }
    }
  }
  console.log(`  ✓ Created ${attendanceCount} attendance logs, ${activityCount} daily activities`)

  // Settings
  await db.setting.create({ data: { key: 'schoolName', value: 'Sunshine Kids Preschool & Daycare' } })
  await db.setting.create({ data: { key: 'kioskPin',   value: '1234' } })
  await db.setting.create({ data: { key: 'currency',   value: 'LKR' } })
  await db.setting.create({ data: { key: 'checkInWindowStart',  value: '07:30' } })
  await db.setting.create({ data: { key: 'checkOutWindowEnd',   value: '17:30' } })

  console.log('✅ Seed completed successfully')
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => { await db.$disconnect() })
