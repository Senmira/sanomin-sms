'use client'

import { useEffect, useState, useCallback } from 'react'
import * as Icons from 'lucide-react'
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend,
  LineChart, Line, PieChart, Pie, Cell,
} from 'recharts'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { api, fmtDate, fmtTime } from '@/lib/api'
import type { AttendanceLog, Role } from '@/lib/types'
import { useToast } from '@/hooks/use-toast'

const STATUS_COLORS: Record<string, string> = {
  PRESENT: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
  LATE:    'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
  ABSENT:  'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',
}

const PIE_COLORS = ['#10b981', '#f59e0b', '#f43f5e', '#8b5cf6', '#06b6d4']

export function AttendanceView({ role }: { role: Role }) {
  const { toast } = useToast()
  const [logs, setLogs] = useState<AttendanceLog[]>([])
  const [loading, setLoading] = useState(true)
  const [range, setRange] = useState<'week' | 'month'>('week')

  const load = useCallback(() => {
    setLoading(true)
    api.getAttendance({ range })
      .then((r) => setLogs(r.logs))
      .catch((e) => toast({ title: 'Failed to load', description: e.message, variant: 'destructive' }))
      .finally(() => setLoading(false))
  }, [range, toast])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load()
  }, [load])

  // Aggregate stats
  const present = logs.filter((l) => l.status === 'PRESENT').length
  const late = logs.filter((l) => l.status === 'LATE').length
  const absent = logs.filter((l) => l.status === 'ABSENT').length
  const total = logs.length || 1
  const rate = Math.round(((present + late) / total) * 100)

  // Daily attendance trend
  const dailyMap: Record<string, { date: string; present: number; late: number; absent: number }> = {}
  for (const l of logs) {
    const d = fmtDate(l.date)
    if (!dailyMap[d]) dailyMap[d] = { date: d, present: 0, late: 0, absent: 0 }
    if (l.status === 'PRESENT') dailyMap[d].present++
    else if (l.status === 'LATE') dailyMap[d].late++
    else if (l.status === 'ABSENT') dailyMap[d].absent++
  }
  const dailyData = Object.values(dailyMap).slice(-14)

  // Status distribution
  const statusData = [
    { name: 'Present', value: present, fill: '#10b981' },
    { name: 'Late', value: late, fill: '#f59e0b' },
    { name: 'Absent', value: absent, fill: '#f43f5e' },
  ]

  // Check-in method distribution
  const methodMap: Record<string, number> = {}
  for (const l of logs) {
    if (l.checkInTime) methodMap[l.method] = (methodMap[l.method] ?? 0) + 1
  }
  const methodData = Object.entries(methodMap).map(([k, v], i) => ({ name: k, value: v, fill: PIE_COLORS[i % PIE_COLORS.length] }))

  // Average check-in time
  const checkInTimes = logs.filter((l) => l.checkInTime).map((l) => new Date(l.checkInTime!).getTime())
  const avgCheckInMs = checkInTimes.length > 0 ? checkInTimes.reduce((s, t) => s + t, 0) / checkInTimes.length : 0
  const avgCheckIn = avgCheckInMs ? fmtTime(new Date(avgCheckInMs)) : '—'

  return (
    <div className="space-y-5">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Attendance History</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {logs.length} records in the selected range · attendance rate {rate}%
          </p>
        </div>
        <Select value={range} onValueChange={(v) => setRange(v as 'week' | 'month')}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="week">Last 7 days</SelectItem>
            <SelectItem value="month">Last 30 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard icon={Icons.CheckCircle2} label="Present" value={present} tone="text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-300" />
        <StatCard icon={Icons.Clock} label="Late" value={late} tone="text-amber-600 bg-amber-50 dark:bg-amber-950/40 dark:text-amber-300" />
        <StatCard icon={Icons.XCircle} label="Absent" value={absent} tone="text-rose-600 bg-rose-50 dark:bg-rose-950/40 dark:text-rose-300" />
        <StatCard icon={Icons.TrendingUp} label="Avg Check-In" value={avgCheckIn} tone="text-violet-600 bg-violet-50 dark:bg-violet-950/40 dark:text-violet-300" small />
      </div>

      {loading ? (
        <div className="space-y-4">
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
        </div>
      ) : (
        <>
          {/* Daily trend */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Daily Attendance Trend</CardTitle>
              <CardDescription>Last {dailyData.length} active days</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={dailyData} margin={{ top: 5, right: 10, left: -15, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" tick={{ fontSize: 10 }} angle={-30} textAnchor="end" height={50} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="present" name="Present" stackId="a" fill="#10b981" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="late" name="Late" stackId="a" fill="#f59e0b" />
                  <Bar dataKey="absent" name="Absent" stackId="a" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Pie charts */}
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={75} label>
                      {statusData.map((d, i) => <Cell key={i} fill={d.fill} />)}
                    </Pie>
                    <Tooltip />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Check-In Methods</CardTitle>
                <CardDescription>QR / RFID / Kiosk / Manual usage</CardDescription>
              </CardHeader>
              <CardContent>
                {methodData.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-12">No check-in data in range.</p>
                ) : (
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie data={methodData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={75} paddingAngle={2} label>
                        {methodData.map((d, i) => <Cell key={i} fill={d.fill} />)}
                      </Pie>
                      <Tooltip />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Recent logs */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Recent Attendance Records</CardTitle>
              <CardDescription>Showing latest {Math.min(logs.length, 100)} records</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="max-h-96 overflow-y-auto rounded-md border">
                <table className="w-full text-xs">
                  <thead className="bg-muted/50 sticky top-0">
                    <tr>
                      <th className="text-left font-medium p-2.5">Student</th>
                      <th className="text-left font-medium p-2.5 hidden sm:table-cell">Code</th>
                      <th className="text-left font-medium p-2.5">Date</th>
                      <th className="text-left font-medium p-2.5">Check In</th>
                      <th className="text-left font-medium p-2.5">Check Out</th>
                      <th className="text-left font-medium p-2.5">Status</th>
                      <th className="text-left font-medium p-2.5 hidden md:table-cell">Method</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.slice(0, 100).map((l) => (
                      <tr key={l.id} className="border-t hover:bg-accent/30">
                        <td className="p-2.5 font-medium">{l.student?.fullName}</td>
                        <td className="p-2.5 text-muted-foreground hidden sm:table-cell font-mono">{l.student?.studentCode}</td>
                        <td className="p-2.5">{fmtDate(l.date)}</td>
                        <td className="p-2.5 font-mono">{fmtTime(l.checkInTime)}</td>
                        <td className="p-2.5 font-mono">{fmtTime(l.checkOutTime)}</td>
                        <td className="p-2.5"><Badge className={`text-[10px] ${STATUS_COLORS[l.status] ?? ''}`}>{l.status}</Badge></td>
                        <td className="p-2.5 hidden md:table-cell"><Badge variant="outline" className="text-[10px]">{l.method}</Badge></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}

function StatCard({ icon: Icon, label, value, tone, small }: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: number | string
  tone: string
  small?: boolean
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`grid h-9 w-9 place-items-center rounded-lg ${tone}`}>
            <Icon className="h-4.5 w-4.5" />
          </div>
          <div>
            <p className="text-[11px] text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className={small ? 'text-base font-bold' : 'text-2xl font-bold'}>{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
