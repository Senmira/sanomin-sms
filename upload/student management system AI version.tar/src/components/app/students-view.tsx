'use client'

import { useEffect, useState, useMemo, useCallback } from 'react'
import * as Icons from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { api, fmtDate, fmtLKR, fmtTime, calcAge } from '@/lib/api'
import type { Student, Program, Role } from '@/lib/types'
import { useToast } from '@/hooks/use-toast'

const STATUS_COLORS: Record<string, string> = {
  ACTIVE:     'bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-900/40 dark:text-emerald-300',
  GRADUATED:  'bg-blue-100 text-blue-700 hover:bg-blue-100',
  WITHDRAWN:  'bg-rose-100 text-rose-700 hover:bg-rose-100',
  SUSPENDED:  'bg-amber-100 text-amber-700 hover:bg-amber-100',
}

const PROGRAM_COLORS: Record<string, string> = {
  PRESCHOOL: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
  Daycare:   'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
  IT:        'bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300',
  Elocution: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',
  Dancing:   'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300',
}

export function StudentsView({ role }: { role: Role }) {
  const { toast } = useToast()
  const [students, setStudents] = useState<Student[]>([])
  const [programs, setPrograms] = useState<Program[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [programFilter, setProgramFilter] = useState('ALL')
  const [ageFilter, setAgeFilter] = useState('ALL')
  const [genderFilter, setGenderFilter] = useState('ALL')
  const [detail, setDetail] = useState<Student | null>(null)
  const [detailOpen, setDetailOpen] = useState(false)

  const load = useCallback(() => {
    setLoading(true)
    Promise.all([
      api.listStudents({
        search,
        program: programFilter === 'ALL' ? undefined : programFilter,
        ageGroup: ageFilter === 'ALL' ? undefined : ageFilter,
        gender: genderFilter === 'ALL' ? undefined : genderFilter,
      }),
      api.listPrograms(),
    ])
      .then(([s, p]) => {
        setStudents(s.students)
        setPrograms(p.programs.map((pp: any) => ({ id: pp.id, code: pp.code, name: pp.name, description: pp.description, monthlyFee: pp.monthlyFee, capacity: pp.capacity, color: pp.color, createdAt: '', updatedAt: '' })))
      })
      .catch((e) => toast({ title: 'Failed to load students', description: e.message, variant: 'destructive' }))
      .finally(() => setLoading(false))
  }, [search, programFilter, ageFilter, genderFilter, toast])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load()
  }, [load])

  const onOpenDetail = (s: Student) => {
    api.getStudent(s.id).then((r) => {
      setDetail(r.student as any)
      setDetailOpen(true)
    }).catch((e) => toast({ title: 'Failed to load student', description: e.message, variant: 'destructive' }))
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Students</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {students.length} records · {role === 'TEACHER' ? 'You can view your class only (RBAC)' : role === 'FINANCE' ? 'Viewing roster for billing context' : 'Full administrative access'}
          </p>
        </div>
        {role === 'ADMIN' && (
          <Button size="sm" onClick={() => toast({ title: 'Coming soon', description: 'The Add Student form is part of Phase 2 enhancements.' })}>
            <Icons.Plus className="h-4 w-4 mr-1.5" />
            Add Student
          </Button>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-2.5">
            <div className="relative flex-1">
              <Icons.Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name, student code (P24001) or index number..."
                className="pl-9"
              />
            </div>
            <Select value={programFilter} onValueChange={setProgramFilter}>
              <SelectTrigger className="w-full md:w-44"><SelectValue placeholder="Program" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Programs</SelectItem>
                {programs.map((p) => <SelectItem key={p.code} value={p.code}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={ageFilter} onValueChange={setAgeFilter}>
              <SelectTrigger className="w-full md:w-36"><SelectValue placeholder="Age Group" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Ages</SelectItem>
                {['1-2', '2-3', '3-4', '4-5'].map((a) => <SelectItem key={a} value={a}>{a} years</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={genderFilter} onValueChange={setGenderFilter}>
              <SelectTrigger className="w-full md:w-32"><SelectValue placeholder="Gender" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Genders</SelectItem>
                <SelectItem value="Male">Male</SelectItem>
                <SelectItem value="Female">Female</SelectItem>
              </SelectContent>
            </Select>
            {(search || programFilter !== 'ALL' || ageFilter !== 'ALL' || genderFilter !== 'ALL') && (
              <Button variant="ghost" onClick={() => { setSearch(''); setProgramFilter('ALL'); setAgeFilter('ALL'); setGenderFilter('ALL') }}>
                <Icons.X className="h-3.5 w-3.5" /> Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* List */}
      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
        </div>
      ) : students.length === 0 ? (
        <Card><CardContent className="p-10 text-center text-muted-foreground">
          <Icons.SearchX className="mx-auto h-10 w-10 mb-3 opacity-50" />
          <p className="font-medium">No students found</p>
          <p className="text-sm">Try adjusting your filters or search terms.</p>
        </CardContent></Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {students.map((s) => {
            const initials = s.fullName.split(' ').map((n) => n[0]).slice(0, 2).join('')
            return (
              <Card key={s.id} className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer" onClick={() => onOpenDetail(s)}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-11 w-11 shrink-0">
                      <AvatarFallback className={`text-sm font-semibold ${s.gender === 'Female' ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300'}`}>
                        {initials}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="font-semibold text-sm truncate">{s.fullName}</p>
                          <p className="text-[11px] text-muted-foreground font-mono">{s.studentCode} · #{s.indexNo}</p>
                        </div>
                        <Badge className={`text-[10px] shrink-0 ${STATUS_COLORS[s.status] ?? ''}`}>{s.status}</Badge>
                      </div>
                      <div className="flex flex-wrap items-center gap-1 mt-2">
                        <Badge variant="outline" className="text-[10px]">{calcAge(s.dob)}</Badge>
                        <Badge variant="outline" className="text-[10px]">{s.ageGroup} yrs</Badge>
                        {s.enrollments?.slice(0, 3).map((e) => (
                          <Badge key={e.programId} className={`text-[10px] ${PROGRAM_COLORS[e.program.code] ?? 'bg-muted'}`}>{e.program.name}</Badge>
                        ))}
                        {(s.enrollments?.length ?? 0) > 3 && (
                          <Badge variant="outline" className="text-[10px]">+{(s.enrollments?.length ?? 0) - 3}</Badge>
                        )}
                      </div>
                      {s.guardians?.[0] && (
                        <p className="text-[11px] text-muted-foreground mt-2 truncate">
                          <Icons.Phone className="inline h-3 w-3 mr-1" />
                          {s.guardians[0].name} · {s.guardians[0].phone}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      <StudentDetailDialog
        student={detail}
        open={detailOpen}
        onOpenChange={setDetailOpen}
        canEdit={role === 'ADMIN'}
        onSaved={() => { load(); setDetailOpen(false) }}
      />
    </div>
  )
}

function StudentDetailDialog({ student, open, onOpenChange, canEdit, onSaved }: {
  student: any
  open: boolean
  onOpenChange: (v: boolean) => void
  canEdit: boolean
  onSaved: () => void
}) {
  const { toast } = useToast()
  const [editMode, setEditMode] = useState(false)
  const [form, setForm] = useState<any>({})
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (student) {
      setForm({
        fullName: student.fullName,
        gender: student.gender,
        dob: student.dob?.slice(0, 10),
        ageGroup: student.ageGroup,
        religion: student.religion,
        nationality: student.nationality,
        previousSchool: student.previousSchool,
        status: student.status,
        notes: student.notes,
      })
      setEditMode(false)
    }
  }, [student])

  if (!student) return null

  const save = async () => {
    setSaving(true)
    try {
      await api.updateStudent(student.id, form)
      toast({ title: 'Student updated', description: `${form.fullName}'s record has been saved.` })
      onSaved()
    } catch (e: any) {
      toast({ title: 'Failed to update', description: e.message, variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {student.fullName}
            <Badge className={`text-[10px] ${STATUS_COLORS[student.status] ?? ''}`}>{student.status}</Badge>
          </DialogTitle>
          <DialogDescription>
            {student.studentCode} · Index #{student.indexNo} · Admitted {fmtDate(student.admissionDate)}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="overview">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="guardians">Guardians</TabsTrigger>
            <TabsTrigger value="attendance">Attendance</TabsTrigger>
            <TabsTrigger value="fees">Fees</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-3 mt-3">
            {editMode ? (
              <div className="grid sm:grid-cols-2 gap-3">
                <Field label="Full Name"><Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></Field>
                <Field label="Gender">
                  <Select value={form.gender} onValueChange={(v) => setForm({ ...form, gender: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="Male">Male</SelectItem><SelectItem value="Female">Female</SelectItem></SelectContent>
                  </Select>
                </Field>
                <Field label="Date of Birth"><Input type="date" value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} /></Field>
                <Field label="Age Group">
                  <Select value={form.ageGroup} onValueChange={(v) => setForm({ ...form, ageGroup: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['1-2', '2-3', '3-4', '4-5'].map((a) => <SelectItem key={a} value={a}>{a} years</SelectItem>)}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Religion"><Input value={form.religion} onChange={(e) => setForm({ ...form, religion: e.target.value })} /></Field>
                <Field label="Nationality"><Input value={form.nationality} onChange={(e) => setForm({ ...form, nationality: e.target.value })} /></Field>
                <Field label="Status">
                  <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACTIVE">Active</SelectItem>
                      <SelectItem value="GRADUATED">Graduated</SelectItem>
                      <SelectItem value="WITHDRAWN">Withdrawn</SelectItem>
                      <SelectItem value="SUSPENDED">Suspended</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Previous School" className="sm:col-span-2"><Input value={form.previousSchool} onChange={(e) => setForm({ ...form, previousSchool: e.target.value })} /></Field>
                <Field label="Notes" className="sm:col-span-2"><Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 gap-3">
                <Info label="Gender" value={student.gender} />
                <Info label="Date of Birth" value={`${fmtDate(student.dob)} (${calcAge(student.dob)})`} />
                <Info label="Age Group" value={student.ageGroup + ' years'} />
                <Info label="Religion" value={student.religion || '—'} />
                <Info label="Nationality" value={student.nationality || '—'} />
                <Info label="Previous School" value={student.previousSchool || '—'} />
                <Info label="Admission Date" value={fmtDate(student.admissionDate)} />
                <Info label="Status" value={student.status} />
                {student.notes && <Info label="Notes" value={student.notes} fullWidth />}
              </div>
            )}

            <div className="space-y-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Enrolled Programs</p>
              <div className="flex flex-wrap gap-1.5">
                {student.enrollments?.map((e: any) => (
                  <Badge key={e.programId} className={`text-[11px] ${PROGRAM_COLORS[e.program.code] ?? ''}`}>
                    {e.program.name}
                  </Badge>
                ))}
              </div>
            </div>

            {student.healthAlerts?.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
                  <Icons.HeartPulse className="h-3.5 w-3.5 text-rose-500" /> Active Health Alerts
                </p>
                <div className="space-y-1.5">
                  {student.healthAlerts.map((h: any) => (
                    <div key={h.id} className="flex items-start gap-2 rounded-md border border-rose-200 dark:border-rose-900/50 bg-rose-50 dark:bg-rose-950/30 p-2">
                      <Badge className={`text-[10px] ${h.severity === 'HIGH' ? 'bg-rose-200 text-rose-800' : h.severity === 'MEDIUM' ? 'bg-amber-200 text-amber-800' : 'bg-emerald-200 text-emerald-800'}`}>{h.severity}</Badge>
                      <div>
                        <p className="text-xs font-medium">{h.type}</p>
                        <p className="text-[11px] text-muted-foreground">{h.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="guardians" className="space-y-2 mt-3">
            {student.guardians?.length === 0 && <p className="text-sm text-muted-foreground">No guardians on file.</p>}
            {student.guardians?.map((g: any) => (
              <Card key={g.id}><CardContent className="p-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-medium">{g.name}</p>
                    <p className="text-xs text-muted-foreground">{g.relationship}</p>
                  </div>
                  {g.emergencyContact && <Badge variant="outline" className="text-[10px]">Emergency</Badge>}
                </div>
                <div className="mt-2 space-y-1 text-xs">
                  <p><Icons.Phone className="inline h-3 w-3 mr-1" />{g.phone}</p>
                  <p><Icons.MapPin className="inline h-3 w-3 mr-1" />{g.address}</p>
                </div>
              </CardContent></Card>
            ))}
          </TabsContent>

          <TabsContent value="attendance" className="mt-3">
            <div className="max-h-72 overflow-y-auto rounded-md border">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 sticky top-0">
                  <tr>
                    <th className="text-left font-medium p-2">Date</th>
                    <th className="text-left font-medium p-2">Check In</th>
                    <th className="text-left font-medium p-2">Check Out</th>
                    <th className="text-left font-medium p-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {student.attendance?.length === 0 && <tr><td colSpan={4} className="p-4 text-center text-muted-foreground">No attendance recorded yet.</td></tr>}
                  {student.attendance?.map((a: any) => (
                    <tr key={a.id} className="border-t">
                      <td className="p-2">{fmtDate(a.date)}</td>
                      <td className="p-2">{fmtTime(a.checkInTime)}</td>
                      <td className="p-2">{fmtTime(a.checkOutTime)}</td>
                      <td className="p-2"><Badge variant="outline" className="text-[10px]">{a.status}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="fees" className="mt-3">
            <div className="max-h-72 overflow-y-auto rounded-md border">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 sticky top-0">
                  <tr>
                    <th className="text-left font-medium p-2">Period</th>
                    <th className="text-left font-medium p-2">Program</th>
                    <th className="text-right font-medium p-2">Amount</th>
                    <th className="text-right font-medium p-2">Paid</th>
                    <th className="text-left font-medium p-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {student.fees?.length === 0 && <tr><td colSpan={5} className="p-4 text-center text-muted-foreground">No fees on file.</td></tr>}
                  {student.fees?.map((f: any) => (
                    <tr key={f.id} className="border-t">
                      <td className="p-2 font-mono">{f.period}</td>
                      <td className="p-2">{f.program?.name ?? '—'}</td>
                      <td className="p-2 text-right">{fmtLKR(f.amount)}</td>
                      <td className="p-2 text-right">{fmtLKR(f.paidAmount)}</td>
                      <td className="p-2"><FeeStatusBadge status={f.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          {canEdit && !editMode && <Button variant="outline" onClick={() => setEditMode(true)}><Icons.Pencil className="h-3.5 w-3.5 mr-1.5" />Edit</Button>}
          {editMode && (
            <>
              <Button variant="ghost" onClick={() => setEditMode(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving}>{saving ? <Icons.Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : null}Save Changes</Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={className}>
      <Label className="text-xs text-muted-foreground mb-1 block">{label}</Label>
      {children}
    </div>
  )
}

function Info({ label, value, fullWidth }: { label: string; value: string; fullWidth?: boolean }) {
  return (
    <div className={fullWidth ? 'sm:col-span-2' : ''}>
      <p className="text-xs text-muted-foreground mb-0.5">{label}</p>
      <p className="text-sm font-medium">{value}</p>
    </div>
  )
}

function FeeStatusBadge({ status }: { status: string }) {
  const m: Record<string, string> = {
    PAID: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    PARTIAL: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
    PENDING: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',
    OVERDUE: 'bg-rose-200 text-rose-900',
  }
  return <Badge className={`text-[10px] ${m[status] ?? ''}`}>{status}</Badge>
}
