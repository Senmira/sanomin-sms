'use client'

import { useEffect, useState, useCallback } from 'react'
import * as Icons from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Skeleton } from '@/components/ui/skeleton'
import { api, fmtTime } from '@/lib/api'
import type { Student, AttendanceLog, Role } from '@/lib/types'
import { ROLE_STAFF } from '@/lib/types'
import { useToast } from '@/hooks/use-toast'

export function CheckInView({ role }: { role: Role }) {
  const { toast } = useToast()
  const [students, setStudents] = useState<Student[]>([])
  const [roster, setRoster] = useState<AttendanceLog[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [acting, setActing] = useState<string | null>(null)
  const [tab, setTab] = useState<'checkin' | 'checkout'>('checkin')

  const load = useCallback(() => {
    setLoading(true)
    Promise.all([
      api.listStudents({ status: 'ACTIVE' }),
      api.getAttendance({ range: 'today' }),
    ])
      .then(([s, a]) => { setStudents(s.students); setRoster(a.logs) })
      .catch((e) => toast({ title: 'Failed to load', description: e.message, variant: 'destructive' }))
      .finally(() => setLoading(false))
  }, [toast])

  useEffect(() => {
    load()
  }, [load])

  const findTodayLog = (studentId: string) => roster.find((r) => r.studentId === studentId)

  const filtered = students.filter((s) => {
    if (!search.trim()) return true
    const q = search.toLowerCase()
    return s.fullName.toLowerCase().includes(q) || s.studentCode.toLowerCase().includes(q) || s.indexNo.includes(q)
  })

  const doAction = async (studentId: string, action: 'checkIn' | 'checkOut') => {
    setActing(studentId)
    const staff = ROLE_STAFF[role].code
    try {
      if (action === 'checkIn') {
        await api.checkIn(studentId, role === 'KIOSK' ? 'KIOSK' : 'QR', staff)
        toast({ title: 'Checked in', description: `${students.find((s) => s.id === studentId)?.fullName} checked in successfully`, className: 'border-emerald-500' })
      } else {
        await api.checkOut(studentId, staff)
        toast({ title: 'Checked out', description: `${students.find((s) => s.id === studentId)?.fullName} checked out successfully` })
      }
      await load()
    } catch (e: any) {
      toast({ title: 'Action failed', description: e.message, variant: 'destructive' })
    } finally {
      setActing(null)
    }
  }

  const stats = {
    present: roster.filter((r) => r.checkInTime).length,
    stillIn: roster.filter((r) => r.checkInTime && !r.checkOutTime).length,
    checkedOut: roster.filter((r) => r.checkOutTime).length,
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Check-In / Check-Out Kiosk</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Quick check-in via QR code, RFID badge, or kiosk touch — signed in as <strong>{ROLE_STAFF[role].name}</strong> ({role})
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="p-4 text-center">
            <Icons.LogIn className="h-5 w-5 mx-auto text-emerald-500 mb-1" />
            <p className="text-2xl font-bold">{stats.present}</p>
            <p className="text-[11px] text-muted-foreground">Checked In Today</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Icons.Users className="h-5 w-5 mx-auto text-amber-500 mb-1" />
            <p className="text-2xl font-bold">{stats.stillIn}</p>
            <p className="text-[11px] text-muted-foreground">Still In Care</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Icons.LogOut className="h-5 w-5 mx-auto text-muted-foreground mb-1" />
            <p className="text-2xl font-bold">{stats.checkedOut}</p>
            <p className="text-[11px] text-muted-foreground">Checked Out</p>
          </CardContent>
        </Card>
      </div>

      {/* Action toggle */}
      <Tabs value={tab} onValueChange={(v) => setTab(v as 'checkin' | 'checkout')}>
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="checkin" className="data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-900 dark:data-[state=active]:bg-emerald-900/40">
            <Icons.LogIn className="h-3.5 w-3.5 mr-1.5" />Check In
          </TabsTrigger>
          <TabsTrigger value="checkout" className="data-[state=active]:bg-amber-100 data-[state=active]:text-amber-900 dark:data-[state=active]:bg-amber-900/40">
            <Icons.LogOut className="h-3.5 w-3.5 mr-1.5" />Check Out
          </TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4 space-y-4">
          {/* Search box */}
          <Card>
            <CardContent className="p-4">
              <div className="relative">
                <Icons.Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  autoFocus
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={tab === 'checkin' ? 'Scan QR / RFID or search student name to check in...' : 'Search student to check out...'}
                  className="pl-9 h-11 text-base"
                />
              </div>
              <p className="text-[11px] text-muted-foreground mt-2 flex items-center gap-1.5">
                <Icons.QrCode className="h-3 w-3" /> In production, this field accepts input from a USB QR/RFID scanner. Manual search is also supported.
              </p>
            </CardContent>
          </Card>

          {/* Student grid */}
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
              {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
              {filtered.slice(0, 60).map((s) => {
                const log = findTodayLog(s.id)
                const initials = s.fullName.split(' ').map((n) => n[0]).slice(0, 2).join('')
                const canCheckIn = tab === 'checkin' && !log?.checkInTime
                const canCheckOut = tab === 'checkout' && !!log?.checkInTime && !log?.checkOutTime
                const disabled = !canCheckIn && !canCheckOut

                return (
                  <Card key={s.id} className={`overflow-hidden transition-all ${disabled ? 'opacity-60' : 'hover:shadow-md hover:border-emerald-300 dark:hover:border-emerald-700'}`}>
                    <CardContent className="p-3">
                      <div className="flex flex-col items-center text-center gap-1.5">
                        <Avatar className="h-12 w-12">
                          <AvatarFallback className={`text-sm font-semibold ${s.gender === 'Female' ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}>
                            {initials}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0 w-full">
                          <p className="font-medium text-xs truncate">{s.fullName}</p>
                          <p className="text-[10px] text-muted-foreground font-mono">{s.studentCode}</p>
                        </div>
                        {log?.checkInTime && log?.checkOutTime ? (
                          <Badge variant="outline" className="text-[9px] bg-muted">
                            <Icons.Check className="h-2.5 w-2.5 mr-0.5" /> Done · {fmtTime(log.checkOutTime)}
                          </Badge>
                        ) : log?.checkInTime ? (
                          <Badge className="text-[9px] bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                            In · {fmtTime(log.checkInTime)}
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-[9px]">Not checked in</Badge>
                        )}
                        <Button
                          size="sm"
                          className="w-full h-8 text-xs mt-1"
                          disabled={disabled || acting === s.id}
                          onClick={() => doAction(s.id, tab === 'checkin' ? 'checkIn' : 'checkOut')}
                          variant={tab === 'checkin' ? 'default' : 'secondary'}
                        >
                          {acting === s.id ? (
                            <Icons.Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : tab === 'checkin' ? (
                            <><Icons.LogIn className="h-3.5 w-3.5 mr-1" />Check In</>
                          ) : (
                            <><Icons.LogOut className="h-3.5 w-3.5 mr-1" />Check Out</>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}

          {/* Today's roster */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Today's Check-In Log</CardTitle>
              <CardDescription>{roster.length} records · auto-refreshes after each action</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="max-h-72 overflow-y-auto rounded-md border">
                <table className="w-full text-xs">
                  <thead className="bg-muted/50 sticky top-0">
                    <tr>
                      <th className="text-left font-medium p-2">Student</th>
                      <th className="text-left font-medium p-2 hidden sm:table-cell">Age</th>
                      <th className="text-left font-medium p-2">Check In</th>
                      <th className="text-left font-medium p-2">Check Out</th>
                      <th className="text-left font-medium p-2 hidden md:table-cell">Method</th>
                    </tr>
                  </thead>
                  <tbody>
                    {roster.length === 0 && <tr><td colSpan={5} className="p-4 text-center text-muted-foreground">No records yet today.</td></tr>}
                    {roster.slice().reverse().slice(0, 50).map((r) => (
                      <tr key={r.id} className="border-t hover:bg-accent/30">
                        <td className="p-2 font-medium">{r.student?.fullName}</td>
                        <td className="p-2 text-muted-foreground hidden sm:table-cell">{r.student?.ageGroup}</td>
                        <td className="p-2 font-mono">{fmtTime(r.checkInTime)}</td>
                        <td className="p-2 font-mono">{fmtTime(r.checkOutTime)}</td>
                        <td className="p-2 hidden md:table-cell"><Badge variant="outline" className="text-[9px]">{r.method}</Badge></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
