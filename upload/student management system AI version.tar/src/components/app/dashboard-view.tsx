'use client'

import { useEffect, useState } from 'react'
import * as Icons from 'lucide-react'
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, CartesianGrid, Legend, RadialBarChart, RadialBar,
} from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { api, fmtLKR, fmtTime } from '@/lib/api'
import type { DashboardMetrics, Role } from '@/lib/types'
import { Skeleton } from '@/components/ui/skeleton'

const PIE_COLORS = ['#10b981', '#f59e0b', '#8b5cf6', '#f43f5e', '#06b6d4', '#a855f7']

export function DashboardView({ role }: { role: Role }) {
  const [data, setData] = useState<DashboardMetrics | null>(null)
  const [error, setError] = useState<string | null>(null)

  const load = () => {
    setError(null)
    api.getDashboard().then(setData).catch((e) => setError(e.message))
  }
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load()
    const id = setInterval(load, 30_000) // refresh every 30s
    return () => clearInterval(id)
  }, [])

  if (error) return <ErrorBox message={error} onRetry={load} />
  if (!data) return <LoadingSkeleton />

  const { totals, distributions, todayRoster } = data

  // Attendance trend last 14 days (derived from todayRoster is not enough, so we use program counts as a proxy for charts)
  const programData = distributions.programs.map((p) => ({
    name: p.name,
    Enrolled: p.count,
    Capacity: p.capacity,
  }))

  const ageData = Object.entries(distributions.ageGroups).map(([k, v], i) => ({ name: k, value: v, fill: PIE_COLORS[i % PIE_COLORS.length] }))
  const genderData = Object.entries(distributions.genders).map(([k, v], i) => ({ name: k, value: v, fill: PIE_COLORS[i % PIE_COLORS.length] }))
  const religionData = Object.entries(distributions.religions).map(([k, v], i) => ({ name: k || 'Unknown', value: v, fill: PIE_COLORS[i % PIE_COLORS.length] }))

  const collectionRate = totals.totalFees > 0 ? Math.round((totals.collectedFees / totals.totalFees) * 100) : 0
  const attendanceRate = totals.totalStudents > 0 ? Math.round((totals.checkedInToday / totals.totalStudents) * 100) : 0

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Live operational metrics for today, {new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-[11px]">
            <Icons.Clock className="mr-1 h-3 w-3" />
            Updated {fmtTime(data.generatedAt)}
          </Badge>
          <Button variant="outline" size="sm" onClick={load}>
            <Icons.RefreshCw className="mr-1.5 h-3.5 w-3.5" />
            Refresh
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          title="Total Students"
          value={totals.totalStudents.toString()}
          subtitle={`${totals.activeStudents} active`}
          icon={Icons.Users}
          tone="emerald"
        />
        <KpiCard
          title="Checked In Today"
          value={totals.checkedInToday.toString()}
          subtitle={`${totals.stillInCare} still in care`}
          icon={Icons.DoorOpen}
          tone="amber"
        />
        <KpiCard
          title="Pending Payments"
          value={totals.pendingPaymentsCount.toString()}
          subtitle={`${fmtLKR(totals.pendingFees)} due`}
          icon={Icons.CreditCard}
          tone="rose"
        />
        <KpiCard
          title="Active Health Alerts"
          value={totals.activeHealthAlerts.toString()}
          subtitle={`${distributions.healthBySeverity.HIGH ?? 0} high severity`}
          icon={Icons.HeartPulse}
          tone="violet"
        />
      </div>

      {/* Revenue + Attendance Rate progress */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Fee Collection Status</CardTitle>
            <CardDescription className="text-2xl font-bold text-foreground">
              {fmtLKR(totals.collectedFees)} <span className="text-sm font-normal text-muted-foreground">of {fmtLKR(totals.totalFees)}</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-medium">Collected</span>
                  <span className="text-muted-foreground">{collectionRate}%</span>
                </div>
                <Progress value={collectionRate} className="h-2.5 bg-muted" indicatorClassName="bg-emerald-500" />
              </div>
              <div className="grid grid-cols-3 gap-3 pt-1 text-xs">
                <div>
                  <p className="text-muted-foreground">Collected</p>
                  <p className="font-semibold text-emerald-600">{fmtLKR(totals.collectedFees)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Pending</p>
                  <p className="font-semibold text-amber-600">{fmtLKR(totals.pendingFees - totals.overdueFees)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Overdue</p>
                  <p className="font-semibold text-rose-600">{fmtLKR(totals.overdueFees)}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Today's Attendance</CardTitle>
            <CardDescription className="text-2xl font-bold text-foreground">
              {totals.checkedInToday} <span className="text-sm font-normal text-muted-foreground">of {totals.totalStudents} students</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-medium">Attendance Rate</span>
                  <span className="text-muted-foreground">{attendanceRate}%</span>
                </div>
                <Progress value={attendanceRate} className="h-2.5 bg-muted" indicatorClassName="bg-amber-500" />
              </div>
              <div className="grid grid-cols-3 gap-3 pt-1 text-xs">
                <div>
                  <p className="text-muted-foreground">Present</p>
                  <p className="font-semibold text-emerald-600">{totals.checkedInToday}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Absent</p>
                  <p className="font-semibold text-rose-600">{totals.absentToday}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Checked Out</p>
                  <p className="font-semibold text-muted">{totals.checkedOutToday}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Program Enrollment vs Capacity</CardTitle>
            <CardDescription>Active enrolments across the 5 programs offered</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={programData} margin={{ top: 5, right: 10, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="Capacity" fill="#e5e7eb" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Enrolled" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Age Group Mix</CardTitle>
            <CardDescription>Distribution across age cohorts</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={ageData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={80} paddingAngle={2}>
                  {ageData.map((d, i) => (
                    <Cell key={i} fill={d.fill} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Gender Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={genderData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label>
                  {genderData.map((d, i) => <Cell key={i} fill={d.fill} />)}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Religion Distribution</CardTitle>
            <CardDescription>Cultural diversity across enrolled students</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={religionData} layout="vertical" margin={{ top: 5, right: 20, left: 30, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={80} />
                <Tooltip />
                <Bar dataKey="value" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Today's roster */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Today's Roster — Live Check-in Status</CardTitle>
          <CardDescription>
            Showing {todayRoster.length} attendance records for today · auto-refreshes every 30s
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="max-h-96 overflow-y-auto rounded-md border">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 sticky top-0 z-10">
                <tr>
                  <th className="text-left font-medium p-2.5">Student</th>
                  <th className="text-left font-medium p-2.5 hidden sm:table-cell">Code</th>
                  <th className="text-left font-medium p-2.5 hidden md:table-cell">Age Group</th>
                  <th className="text-left font-medium p-2.5">Check In</th>
                  <th className="text-left font-medium p-2.5">Check Out</th>
                  <th className="text-left font-medium p-2.5">Status</th>
                </tr>
              </thead>
              <tbody>
                {todayRoster.length === 0 && (
                  <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No attendance recorded today yet.</td></tr>
                )}
                {todayRoster.slice(0, 50).map((r) => (
                  <tr key={r.id} className="border-t hover:bg-accent/30">
                    <td className="p-2.5 font-medium">{r.studentName}</td>
                    <td className="p-2.5 text-muted-foreground hidden sm:table-cell text-xs font-mono">{r.studentCode}</td>
                    <td className="p-2.5 hidden md:table-cell"><Badge variant="outline" className="text-[10px]">{r.ageGroup}</Badge></td>
                    <td className="p-2.5 text-xs">{fmtTime(r.checkInTime)}</td>
                    <td className="p-2.5 text-xs">{fmtTime(r.checkOutTime)}</td>
                    <td className="p-2.5">
                      <StatusBadge status={r.status} checkOut={!!r.checkOutTime} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function KpiCard({ title, value, subtitle, icon: Icon, tone }: {
  title: string
  value: string
  subtitle: string
  icon: React.ComponentType<{ className?: string }>
  tone: 'emerald' | 'amber' | 'rose' | 'violet'
}) {
  const tones = {
    emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-300',
    amber:   'bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-300',
    rose:    'bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-300',
    violet:  'bg-violet-50 text-violet-600 dark:bg-violet-950/40 dark:text-violet-300',
  }
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{title}</p>
            <p className="text-3xl font-bold tracking-tight">{value}</p>
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          </div>
          <div className={`grid h-10 w-10 place-items-center rounded-xl ${tones[tone]}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function StatusBadge({ status, checkOut }: { status: string; checkOut: boolean }) {
  if (checkOut) return <Badge className="bg-muted text-muted-foreground text-[10px]">Checked Out</Badge>
  if (status === 'PRESENT') return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 text-[10px]">Present</Badge>
  if (status === 'LATE') return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-[10px]">Late</Badge>
  if (status === 'ABSENT') return <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100 text-[10px]">Absent</Badge>
  return <Badge variant="outline" className="text-[10px]">{status}</Badge>
}

function LoadingSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-12 w-72" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-40 rounded-xl" />)}
      </div>
      <Skeleton className="h-96 rounded-xl" />
    </div>
  )
}

function ErrorBox({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <Card>
      <CardContent className="p-8 text-center">
        <Icons.AlertCircle className="mx-auto h-10 w-10 text-rose-500" />
        <p className="mt-3 font-medium">Failed to load dashboard</p>
        <p className="text-sm text-muted-foreground mt-1">{message}</p>
        <Button className="mt-4" onClick={onRetry}>Try again</Button>
      </CardContent>
    </Card>
  )
}
