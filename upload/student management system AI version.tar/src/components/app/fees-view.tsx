'use client'

import { useEffect, useState, useCallback } from 'react'
import * as Icons from 'lucide-react'
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { api, fmtLKR, fmtDate } from '@/lib/api'
import type { Fee, Role } from '@/lib/types'
import { useToast } from '@/hooks/use-toast'

const STATUS_META: Record<string, { color: string; label: string }> = {
  PAID:     { color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300', label: 'Paid' },
  PARTIAL:  { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',         label: 'Partial' },
  PENDING:  { color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',             label: 'Pending' },
  OVERDUE:  { color: 'bg-rose-200 text-rose-900',                                                   label: 'Overdue' },
}

export function FeesView({ role }: { role: Role }) {
  const { toast } = useToast()
  const [fees, setFees] = useState<Fee[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [periodFilter, setPeriodFilter] = useState('ALL')
  const [search, setSearch] = useState('')
  const [payFee, setPayFee] = useState<Fee | null>(null)

  const load = useCallback(() => {
    setLoading(true)
    api.listFees({
      status: statusFilter === 'ALL' ? undefined : statusFilter,
      period: periodFilter === 'ALL' ? undefined : periodFilter,
    })
      .then((r) => setFees(r.fees))
      .catch((e) => toast({ title: 'Failed to load fees', description: e.message, variant: 'destructive' }))
      .finally(() => setLoading(false))
  }, [statusFilter, periodFilter, toast])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load()
  }, [load])

  const filtered = fees.filter((f) => {
    if (!search.trim()) return true
    const q = search.toLowerCase()
    return f.student?.fullName.toLowerCase().includes(q) || f.student?.studentCode.toLowerCase().includes(q)
  })

  const total = fees.reduce((s, f) => s + f.amount, 0)
  const collected = fees.reduce((s, f) => s + f.paidAmount, 0)
  const pending = total - collected
  const overdue = fees.filter((f) => f.status === 'OVERDUE').reduce((s, f) => s + (f.amount - f.paidAmount), 0)

  return (
    <div className="space-y-5">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Fees & Billing</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {role === 'FINANCE' ? 'Finance admin access — full billing visibility' : 'Administrative view of fee records'}
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load}>
          <Icons.RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <SummaryCard icon={Icons.Banknote} label="Total Billed" value={fmtLKR(total)} tone="bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-300" />
        <SummaryCard icon={Icons.CheckCircle2} label="Collected" value={fmtLKR(collected)} tone="bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-300" />
        <SummaryCard icon={Icons.Clock} label="Outstanding" value={fmtLKR(pending)} tone="bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-300" />
        <SummaryCard icon={Icons.AlertCircle} label="Overdue" value={fmtLKR(overdue)} tone="bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-300" />
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-2.5">
            <div className="relative flex-1">
              <Icons.Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search student name or code..." className="pl-9" />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-44"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Statuses</SelectItem>
                <SelectItem value="PENDING">Pending</SelectItem>
                <SelectItem value="PARTIAL">Partial</SelectItem>
                <SelectItem value="PAID">Paid</SelectItem>
                <SelectItem value="OVERDUE">Overdue</SelectItem>
              </SelectContent>
            </Select>
            <Select value={periodFilter} onValueChange={setPeriodFilter}>
              <SelectTrigger className="w-full md:w-40"><SelectValue placeholder="Period" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Periods</SelectItem>
                {Array.from(new Set(fees.map((f) => f.period))).sort().reverse().map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      {loading ? (
        <div className="space-y-2">{Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-14 rounded-md" />)}</div>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="max-h-[600px] overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 sticky top-0 z-10">
                  <tr>
                    <th className="text-left font-medium p-3">Student</th>
                    <th className="text-left font-medium p-3 hidden sm:table-cell">Program</th>
                    <th className="text-left font-medium p-3">Period</th>
                    <th className="text-right font-medium p-3">Amount</th>
                    <th className="text-right font-medium p-3 hidden md:table-cell">Paid</th>
                    <th className="text-right font-medium p-3 hidden md:table-cell">Due</th>
                    <th className="text-left font-medium p-3">Status</th>
                    <th className="text-right font-medium p-3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 && <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">No fee records found.</td></tr>}
                  {filtered.map((f) => {
                    const meta = STATUS_META[f.status] ?? { color: 'bg-muted', label: f.status }
                    const remaining = f.amount - f.paidAmount
                    return (
                      <tr key={f.id} className="border-t hover:bg-accent/30">
                        <td className="p-3">
                          <div>
                            <p className="font-medium">{f.student?.fullName ?? '—'}</p>
                            <p className="text-[10px] text-muted-foreground font-mono">{f.student?.studentCode ?? '—'}</p>
                          </div>
                        </td>
                        <td className="p-3 text-muted-foreground hidden sm:table-cell text-xs">{f.program?.name ?? '—'}</td>
                        <td className="p-3 font-mono text-xs">{f.period}</td>
                        <td className="p-3 text-right font-medium">{fmtLKR(f.amount)}</td>
                        <td className="p-3 text-right text-emerald-600 font-medium hidden md:table-cell">{fmtLKR(f.paidAmount)}</td>
                        <td className="p-3 text-right text-xs text-muted-foreground hidden md:table-cell">{fmtDate(f.dueDate)}</td>
                        <td className="p-3"><Badge className={`text-[10px] ${meta.color}`}>{meta.label}</Badge></td>
                        <td className="p-3 text-right">
                          {remaining > 0 ? (
                            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setPayFee(f)}>
                              <Icons.CreditCard className="h-3 w-3 mr-1" />Record Payment
                            </Button>
                          ) : (
                            <Badge variant="outline" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200">
                              <Icons.Check className="h-3 w-3 mr-0.5" />Settled
                            </Badge>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <PaymentDialog fee={payFee} open={!!payFee} onOpenChange={(v) => !v && setPayFee(null)} onPaid={() => { setPayFee(null); load() }} />
    </div>
  )
}

function SummaryCard({ icon: Icon, label, value, tone }: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  tone: string
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`grid h-9 w-9 place-items-center rounded-lg ${tone}`}>
            <Icon className="h-4.5 w-4.5" />
          </div>
          <div>
            <p className="text-[11px] text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-lg font-bold">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function PaymentDialog({ fee, open, onOpenChange, onPaid }: {
  fee: Fee | null
  open: boolean
  onOpenChange: (v: boolean) => void
  onPaid: () => void
}) {
  const { toast } = useToast()
  const [amount, setAmount] = useState('')
  const [method, setMethod] = useState('CASH')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (fee) {
      setAmount(String(fee.amount - fee.paidAmount))
      setMethod('CASH')
    }
  }, [fee])

  if (!fee) return null
  const remaining = fee.amount - fee.paidAmount

  const submit = async () => {
    const amt = Number(amount)
    if (!amt || amt <= 0) {
      toast({ title: 'Invalid amount', description: 'Enter a positive number.', variant: 'destructive' })
      return
    }
    if (amt > remaining) {
      toast({ title: 'Amount exceeds balance', description: `Maximum remaining is ${fmtLKR(remaining)}.`, variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      await api.recordPayment(fee.id, amt, method)
      toast({ title: 'Payment recorded', description: `${fmtLKR(amt)} via ${method} for ${fee.student?.fullName}.` })
      onPaid()
    } catch (e: any) {
      toast({ title: 'Payment failed', description: e.message, variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Record Payment</DialogTitle>
          <DialogDescription>{fee.student?.fullName} · {fee.period} · {fee.program?.name ?? 'General'}</DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="rounded-md bg-muted/50 p-3 text-sm space-y-1">
            <div className="flex justify-between"><span className="text-muted-foreground">Total amount</span><span className="font-medium">{fmtLKR(fee.amount)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Already paid</span><span className="font-medium text-emerald-600">{fmtLKR(fee.paidAmount)}</span></div>
            <div className="flex justify-between border-t pt-1 mt-1"><span className="font-medium">Remaining balance</span><span className="font-bold text-rose-600">{fmtLKR(remaining)}</span></div>
          </div>

          <div>
            <Label className="text-xs mb-1.5 block">Payment Amount (LKR)</Label>
            <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>

          <div>
            <Label className="text-xs mb-1.5 block">Payment Method</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="CASH">Cash</SelectItem>
                <SelectItem value="CARD">Card</SelectItem>
                <SelectItem value="BANK">Bank Transfer</SelectItem>
                <SelectItem value="ONLINE">Online</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? <Icons.Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Icons.Check className="h-4 w-4 mr-1.5" />}
            Record Payment
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
