'use client'

import { useEffect, useState, useCallback } from 'react'
import * as Icons from 'lucide-react'
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog'
import { api, fmtLKR } from '@/lib/api'
import type { ProgramEnriched, Role } from '@/lib/types'
import { useToast } from '@/hooks/use-toast'

const COLOR_MAP: Record<string, { bg: string; text: string; bar: string; border: string }> = {
  emerald: { bg: 'bg-emerald-50 dark:bg-emerald-950/30', text: 'text-emerald-700 dark:text-emerald-300', bar: 'bg-emerald-500', border: 'border-emerald-200 dark:border-emerald-800' },
  amber:   { bg: 'bg-amber-50 dark:bg-amber-950/30',   text: 'text-amber-700 dark:text-amber-300',     bar: 'bg-amber-500',   border: 'border-amber-200 dark:border-amber-800' },
  violet:  { bg: 'bg-violet-50 dark:bg-violet-950/30', text: 'text-violet-700 dark:text-violet-300',  bar: 'bg-violet-500',  border: 'border-violet-200 dark:border-violet-800' },
  rose:    { bg: 'bg-rose-50 dark:bg-rose-950/30',     text: 'text-rose-700 dark:text-rose-300',      bar: 'bg-rose-500',    border: 'border-rose-200 dark:border-rose-800' },
  cyan:    { bg: 'bg-cyan-50 dark:bg-cyan-950/30',    text: 'text-cyan-700 dark:text-cyan-300',       bar: 'bg-cyan-500',    border: 'border-cyan-200 dark:border-cyan-800' },
}

export function ProgramsView({ role }: { role: Role }) {
  const { toast } = useToast()
  const [programs, setPrograms] = useState<ProgramEnriched[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<ProgramEnriched | null>(null)

  const load = useCallback(() => {
    setLoading(true)
    api.listPrograms()
      .then((r) => setPrograms(r.programs))
      .catch((e) => toast({ title: 'Failed to load programs', description: e.message, variant: 'destructive' }))
      .finally(() => setLoading(false))
  }, [toast])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load()
  }, [load])

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Programs</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {programs.length} active programs · click any program card to view enrolled students
        </p>
      </div>

      {loading ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-xl" />)}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {programs.map((p) => {
            const c = COLOR_MAP[p.color] ?? COLOR_MAP.emerald
            const fillPct = p.capacity > 0 ? Math.min(100, (p.enrolledCount / p.capacity) * 100) : 0
            return (
              <Card
                key={p.id}
                className={`cursor-pointer hover:shadow-md transition-all ${c.border} border`}
                onClick={() => setSelected(p)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className={`grid h-10 w-10 place-items-center rounded-xl ${c.bg} ${c.text}`}>
                        <Icons.Boxes className="h-5 w-5" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{p.name}</CardTitle>
                        <CardDescription className="text-[11px] font-mono">{p.code}</CardDescription>
                      </div>
                    </div>
                    <Badge className={`text-[10px] ${c.bg} ${c.text}`}>{fmtLKR(p.monthlyFee)}/mo</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-xs text-muted-foreground line-clamp-2">{p.description}</p>
                  <div>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="font-medium">{p.enrolledCount} enrolled</span>
                      <span className="text-muted-foreground">{p.capacityLeft} spots left</span>
                    </div>
                    <Progress value={fillPct} className="h-2" indicatorClassName={c.bar} />
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div className={`rounded-md p-2 ${c.bg} ${c.text}`}>
                      <p className="text-[10px] opacity-80">Collected</p>
                      <p className="font-bold">{fmtLKR(p.revenueCollected)}</p>
                    </div>
                    <div className="rounded-md bg-muted/50 p-2">
                      <p className="text-[10px] text-muted-foreground">Pending</p>
                      <p className="font-bold">{fmtLKR(p.revenuePending)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      <ProgramDetailDialog program={selected} open={!!selected} onOpenChange={(v) => !v && setSelected(null)} />
    </div>
  )
}

function ProgramDetailDialog({ program, open, onOpenChange }: {
  program: ProgramEnriched | null
  open: boolean
  onOpenChange: (v: boolean) => void
}) {
  if (!program) return null
  const c = COLOR_MAP[program.color] ?? COLOR_MAP.emerald
  const students = program.students ?? []

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className={`grid h-9 w-9 place-items-center rounded-lg ${c.bg} ${c.text}`}>
              <Icons.Boxes className="h-4.5 w-4.5" />
            </div>
            {program.name}
          </DialogTitle>
          <DialogDescription>{program.description}</DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <Stat label="Enrolled" value={program.enrolledCount.toString()} />
          <Stat label="Capacity" value={program.capacity.toString()} />
          <Stat label="Monthly Fee" value={fmtLKR(program.monthlyFee)} />
          <Stat label="Collected" value={fmtLKR(program.revenueCollected)} />
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            Enrolled Students ({students.length})
          </p>
          <div className="max-h-80 overflow-y-auto rounded-md border">
            {students.length === 0 ? (
              <p className="p-4 text-center text-sm text-muted-foreground">No students enrolled.</p>
            ) : (
              <table className="w-full text-sm">
                <thead className="bg-muted/50 sticky top-0">
                  <tr>
                    <th className="text-left font-medium p-2">Student</th>
                    <th className="text-left font-medium p-2 hidden sm:table-cell">Code</th>
                    <th className="text-left font-medium p-2">Age</th>
                    <th className="text-left font-medium p-2 hidden sm:table-cell">Gender</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((s) => (
                    <tr key={s.id} className="border-t hover:bg-accent/30">
                      <td className="p-2">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-7 w-7">
                            <AvatarFallback className={`text-[10px] font-semibold ${s.gender === 'Female' ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}>
                              {s.fullName.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{s.fullName}</span>
                        </div>
                      </td>
                      <td className="p-2 text-muted-foreground hidden sm:table-cell font-mono text-xs">{s.studentCode}</td>
                      <td className="p-2"><Badge variant="outline" className="text-[10px]">{s.ageGroup}</Badge></td>
                      <td className="p-2 hidden sm:table-cell text-xs">{s.gender}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border p-2.5">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</p>
      <p className="text-base font-bold">{value}</p>
    </div>
  )
}
