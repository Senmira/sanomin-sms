'use client'

import { useState, useCallback } from 'react'
import * as Icons from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

import { navForRole, ROLE_LABELS, ROLE_STAFF, type Role, type NavKey } from '@/lib/types'
import { DashboardView } from '@/components/app/dashboard-view'
import { StudentsView } from '@/components/app/students-view'
import { CheckInView } from '@/components/app/checkin-view'
import { AttendanceView } from '@/components/app/attendance-view'
import { FeesView } from '@/components/app/fees-view'
import { ProgramsView } from '@/components/app/programs-view'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'

export default function Home() {
  const [role, setRole] = useState<Role>('ADMIN')
  const [active, setActive] = useState<NavKey>('dashboard')
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const { toast } = useToast()

  const navItems = navForRole(role)
  // Reset active tab when current role no longer permits it (done during render, no effect)
  const effectiveActive: NavKey = navItems.some((i) => i.key === active) ? active : navItems[0].key
  const setActiveSafe = (key: NavKey) => {
    if (navItems.some((i) => i.key === key)) setActive(key)
  }

  const onRoleChange = useCallback((r: Role) => {
    setRole(r)
    toast({ title: `Switched to ${ROLE_LABELS[r]} role`, description: `Signed in as ${ROLE_STAFF[r].name}` })
  }, [toast])

  const currentStaff = ROLE_STAFF[role]

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/70">
        <div className="flex h-16 items-center gap-3 px-4 lg:px-6">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setMobileNavOpen((v) => !v)}
            aria-label="Toggle navigation"
          >
            {mobileNavOpen ? <Icons.X className="h-5 w-5" /> : <Icons.Menu className="h-5 w-5" />}
          </Button>
          <div className="flex items-center gap-2.5">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-amber-400 text-white shadow-sm">
              <Icons.Sun className="h-5 w-5" />
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-semibold leading-tight">Sunshine Kids</p>
              <p className="text-[11px] text-muted-foreground leading-tight">Preschool & Daycare</p>
            </div>
          </div>

          <div className="ml-auto flex items-center gap-2">
            <Badge variant="outline" className="hidden md:inline-flex bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800">
              <Icons.CircleDot className="mr-1.5 h-3 w-3 animate-pulse" />
              Live
            </Badge>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2 pl-1.5 pr-2">
                  <Avatar className="h-7 w-7">
                    <AvatarFallback className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-200 text-xs font-semibold">
                      {currentStaff.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-left hidden sm:block">
                    <p className="text-xs font-medium leading-tight">{currentStaff.name}</p>
                    <p className="text-[10px] text-muted-foreground leading-tight">{ROLE_LABELS[role]}</p>
                  </div>
                  <Icons.ChevronDown className="h-3.5 w-3.5 opacity-50" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-60">
                <DropdownMenuLabel className="text-xs text-muted-foreground">Switch role (RBAC demo)</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {(['ADMIN', 'TEACHER', 'FINANCE', 'KIOSK'] as Role[]).map((r) => {
                  const s = ROLE_STAFF[r]
                  return (
                    <DropdownMenuItem
                      key={r}
                      onClick={() => onRoleChange(r)}
                      className="flex items-start gap-2 py-2"
                      data-active={role === r}
                    >
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className={`text-xs font-semibold ${roleColorClass(r)}`}>
                          {s.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-sm font-medium leading-tight">{s.name}</p>
                        <p className="text-[11px] text-muted-foreground leading-tight">
                          {ROLE_LABELS[r]}{s.class ? ` · Class ${s.class}` : ''}
                        </p>
                      </div>
                      {role === r && <Icons.Check className="h-4 w-4 text-emerald-600" />}
                    </DropdownMenuItem>
                  )
                })}
                <DropdownMenuSeparator />
                <div className="px-2 py-1.5">
                  <p className="text-[10px] text-muted-foreground leading-tight">
                    Roles control which pages each user can access (Role-Based Access Control).
                  </p>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar — desktop */}
        <aside className="hidden lg:flex w-60 shrink-0 flex-col border-r bg-card/50">
          <nav className="flex-1 p-3 space-y-1">
            {navItems.map((item) => {
              const Icon = (Icons as any)[item.icon] ?? Icons.Circle
              return (
                <button
                  key={item.key}
                  onClick={() => setActiveSafe(item.key)}
                  className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                    effectiveActive === item.key
                      ? 'bg-emerald-100 text-emerald-900 dark:bg-emerald-900/40 dark:text-emerald-100'
                      : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                  }`}
                >
                  <Icon className="h-4.5 w-4.5" />
                  {item.label}
                </button>
              )
            })}
          </nav>
          <div className="p-3 border-t">
            <div className="rounded-lg bg-gradient-to-br from-emerald-500/10 to-amber-400/10 border border-emerald-200/40 p-3">
              <p className="text-xs font-semibold flex items-center gap-1.5">
                <Icons.ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
                COPPA / GDPR
              </p>
              <p className="text-[11px] text-muted-foreground mt-1 leading-snug">
                Data encrypted at rest. Role-based access enforced for child records.
              </p>
            </div>
          </div>
        </aside>

        {/* Sidebar — mobile */}
        <AnimatePresence>
          {mobileNavOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="lg:hidden fixed inset-0 z-50 bg-black/40"
              onClick={() => setMobileNavOpen(false)}
            >
              <motion.aside
                initial={{ x: -280 }}
                animate={{ x: 0 }}
                exit={{ x: -280 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                onClick={(e) => e.stopPropagation()}
                className="absolute left-0 top-0 bottom-0 w-64 bg-card border-r p-3 space-y-1"
              >
                <div className="flex items-center justify-between mb-3 px-2 pt-2">
                  <p className="text-sm font-semibold">Menu</p>
                  <Button variant="ghost" size="icon" onClick={() => setMobileNavOpen(false)}>
                    <Icons.X className="h-4 w-4" />
                  </Button>
                </div>
                {navItems.map((item) => {
                  const Icon = (Icons as any)[item.icon] ?? Icons.Circle
                  return (
                    <button
                      key={item.key}
                      onClick={() => { setActiveSafe(item.key); setMobileNavOpen(false) }}
                      className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                        effectiveActive === item.key ? 'bg-emerald-100 text-emerald-900' : 'text-muted-foreground hover:bg-accent'
                      }`}
                    >
                      <Icon className="h-4.5 w-4.5" />
                      {item.label}
                    </button>
                  )
                })}
              </motion.aside>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main content */}
        <main className="flex-1 min-w-0 p-4 lg:p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={effectiveActive}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              {effectiveActive === 'dashboard'  && <DashboardView role={role} />}
              {effectiveActive === 'students'   && <StudentsView role={role} />}
              {effectiveActive === 'checkin'    && <CheckInView role={role} />}
              {effectiveActive === 'attendance' && <AttendanceView role={role} />}
              {effectiveActive === 'fees'       && <FeesView role={role} />}
              {effectiveActive === 'programs'   && <ProgramsView role={role} />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      <footer className="border-t bg-card/50 px-4 lg:px-6 py-3">
        <p className="text-[11px] text-muted-foreground text-center">
          Sunshine Kids Preschool Management System · MEAN-stack tutorial baseline (Phase 1) · Built with Next.js + Prisma + SQLite · {new Date().getFullYear()}
        </p>
      </footer>
    </div>
  )
}

function roleColorClass(r: Role): string {
  switch (r) {
    case 'ADMIN':   return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-200'
    case 'TEACHER': return 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-200'
    case 'FINANCE': return 'bg-rose-100 text-rose-700 dark:bg-rose-900 dark:text-rose-200'
    case 'KIOSK':   return 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-200'
  }
}
