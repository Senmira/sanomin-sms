import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

// GET /api/attendance?date=YYYY-MM-DD&studentId=...&range=today|week|month
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const dateStr = searchParams.get('date')
  const studentId = searchParams.get('studentId')
  const range = searchParams.get('range')

  const where: any = {}
  if (studentId) where.studentId = studentId

  if (dateStr) {
    const day = new Date(dateStr)
    day.setHours(0, 0, 0, 0)
    const next = new Date(day)
    next.setDate(next.getDate() + 1)
    where.date = { gte: day, lt: next }
  } else if (range === 'week') {
    const start = new Date(); start.setDate(start.getDate() - 7); start.setHours(0, 0, 0, 0)
    where.date = { gte: start }
  } else if (range === 'month') {
    const start = new Date(); start.setMonth(start.getMonth() - 1); start.setHours(0, 0, 0, 0)
    where.date = { gte: start }
  } else {
    const day = new Date(); day.setHours(0, 0, 0, 0)
    const next = new Date(day); next.setDate(next.getDate() + 1)
    where.date = { gte: day, lt: next }
  }

  const logs = await db.attendanceLog.findMany({
    where,
    include: { student: { include: { enrollments: { include: { program: true } } } } },
    orderBy: [{ checkInTime: 'asc' }, { date: 'asc' }],
  })

  return NextResponse.json({ logs, total: logs.length })
}

// POST /api/attendance { studentId, action: 'checkIn'|'checkOut'|'markAbsent', method?, recordedBy? }
export async function POST(req: NextRequest) {
  const body = await req.json()
  const { studentId, action, method = 'KIOSK', recordedBy = 'system' } = body
  if (!studentId || !action) {
    return NextResponse.json({ error: 'studentId and action required' }, { status: 400 })
  }

  const today = new Date(); today.setHours(0, 0, 0, 0)
  const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1)

  let log = await db.attendanceLog.findFirst({
    where: { studentId, date: { gte: today, lt: tomorrow } },
  })

  const now = new Date()

  if (action === 'checkIn') {
    if (log && log.checkInTime) {
      return NextResponse.json({ error: 'Student already checked in today', log }, { status: 409 })
    }
    if (!log) {
      log = await db.attendanceLog.create({
        data: { studentId, date: today, checkInTime: now, method, status: now.getHours() >= 9 ? 'LATE' : 'PRESENT', recordedBy },
      })
    } else {
      log = await db.attendanceLog.update({
        where: { id: log.id },
        data: { checkInTime: now, method, status: now.getHours() >= 9 ? 'LATE' : 'PRESENT', recordedBy },
      })
    }
  } else if (action === 'checkOut') {
    if (!log || !log.checkInTime) {
      return NextResponse.json({ error: 'Student has not checked in today' }, { status: 400 })
    }
    if (log.checkOutTime) {
      return NextResponse.json({ error: 'Student already checked out today', log }, { status: 409 })
    }
    log = await db.attendanceLog.update({
      where: { id: log.id },
      data: { checkOutTime: now, recordedBy },
    })
  } else if (action === 'markAbsent') {
    if (!log) {
      log = await db.attendanceLog.create({
        data: { studentId, date: today, status: 'ABSENT', method: 'MANUAL', recordedBy },
      })
    } else {
      log = await db.attendanceLog.update({
        where: { id: log.id },
        data: { status: 'ABSENT', checkInTime: null, checkOutTime: null },
      })
    }
  } else {
    return NextResponse.json({ error: 'Invalid action. Use checkIn|checkOut|markAbsent' }, { status: 400 })
  }

  return NextResponse.json({ log })
}
