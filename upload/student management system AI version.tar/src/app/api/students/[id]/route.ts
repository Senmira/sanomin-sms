import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const student = await db.student.findUnique({
    where: { id },
    include: {
      guardians: true,
      enrollments: { include: { program: true } },
      attendance: { orderBy: { date: 'desc' }, take: 30 },
      fees: { include: { program: true }, orderBy: { dueDate: 'desc' } },
      activities: { orderBy: { date: 'desc' }, take: 20 },
      healthAlerts: { where: { active: true } },
    },
  })
  if (!student) return NextResponse.json({ error: 'Student not found' }, { status: 404 })
  return NextResponse.json({ student })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const body = await req.json()
  const allowed = ['fullName', 'gender', 'dob', 'ageGroup', 'religion', 'nationality', 'previousSchool', 'status', 'notes', 'photoUrl']
  const data: any = {}
  for (const k of allowed) {
    if (body[k] !== undefined) {
      if (k === 'dob') data.dob = new Date(body[k])
      else data[k] = body[k]
    }
  }
  const updated = await db.student.update({ where: { id }, data })
  return NextResponse.json({ student: updated })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  await db.student.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
