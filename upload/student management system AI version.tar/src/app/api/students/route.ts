import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const search = searchParams.get('search')?.trim() ?? ''
  const program = searchParams.get('program') ?? ''
  const ageGroup = searchParams.get('ageGroup') ?? ''
  const status = searchParams.get('status') ?? ''
  const gender = searchParams.get('gender') ?? ''
  const limit = Number(searchParams.get('limit') ?? 200)

  const where: any = {}
  if (status) where.status = status
  if (gender) where.gender = gender
  if (ageGroup) where.ageGroup = ageGroup
  if (search) {
    where.OR = [
      { fullName: { contains: search } },
      { studentCode: { contains: search } },
      { indexNo: { contains: search } },
    ]
  }
  if (program) {
    where.enrollments = { some: { program: { code: program } } }
  }

  const students = await db.student.findMany({
    where,
    include: {
      guardians: true,
      enrollments: { include: { program: true } },
    },
    orderBy: { studentCode: 'asc' },
    take: limit,
  })

  return NextResponse.json({ students, total: students.length })
}
