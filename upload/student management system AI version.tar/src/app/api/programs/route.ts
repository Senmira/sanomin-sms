import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

// GET /api/programs
export async function GET() {
  const programs = await db.program.findMany({
    include: {
      enrollments: {
        where: { status: 'ACTIVE' },
        include: { student: { select: { id: true, fullName: true, ageGroup: true, gender: true, studentCode: true } } },
      },
      fees: { select: { amount: true, paidAmount: true, status: true } },
    },
    orderBy: { code: 'asc' },
  })

  const enriched = programs.map((p) => {
    const revenueCollected = p.fees.reduce((sum, f) => sum + f.paidAmount, 0)
    const revenuePending = p.fees.reduce((sum, f) => sum + (f.amount - f.paidAmount), 0)
    return {
      id: p.id,
      code: p.code,
      name: p.name,
      description: p.description,
      monthlyFee: p.monthlyFee,
      capacity: p.capacity,
      color: p.color,
      enrolledCount: p.enrollments.length,
      capacityLeft: p.capacity - p.enrollments.length,
      revenueCollected,
      revenuePending,
      students: p.enrollments.map((e) => e.student),
    }
  })

  return NextResponse.json({ programs: enriched })
}
