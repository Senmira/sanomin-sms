import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

// GET /api/fees?status=PENDING&period=YYYY-MM&studentId=...
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status')
  const period = searchParams.get('period')
  const studentId = searchParams.get('studentId')

  const where: any = {}
  if (status) where.status = status
  if (period) where.period = period
  if (studentId) where.studentId = studentId

  const fees = await db.fee.findMany({
    where,
    include: { student: true, program: true },
    orderBy: [{ dueDate: 'asc' }, { period: 'desc' }],
    take: 500,
  })

  return NextResponse.json({ fees, total: fees.length })
}

// POST /api/fees { feeId, amount, method }  -> record a payment (full or partial)
export async function POST(req: NextRequest) {
  const body = await req.json()
  const { feeId, amount, method = 'CASH', recordedBy = 'system' } = body
  if (!feeId || !amount) return NextResponse.json({ error: 'feeId and amount required' }, { status: 400 })

  const fee = await db.fee.findUnique({ where: { id: feeId } })
  if (!fee) return NextResponse.json({ error: 'Fee not found' }, { status: 404 })

  const newPaid = fee.paidAmount + Number(amount)
  const newStatus = newPaid >= fee.amount ? 'PAID' : 'PARTIAL'
  const paidAt = newStatus === 'PAID' ? new Date() : fee.paidAt ?? new Date()

  const updated = await db.fee.update({
    where: { id: feeId },
    data: { paidAmount: newPaid, status: newStatus, method, paidAt },
  })

  return NextResponse.json({ fee: updated })
}
