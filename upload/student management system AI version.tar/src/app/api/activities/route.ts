import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

// GET /api/activities?studentId=...&limit=50
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const studentId = searchParams.get('studentId')
  const limit = Number(searchParams.get('limit') ?? 50)
  const activities = await db.dailyActivity.findMany({
    where: studentId ? { studentId } : undefined,
    include: { student: { select: { id: true, fullName: true, studentCode: true } } },
    orderBy: { date: 'desc' },
    take: limit,
  })
  return NextResponse.json({ activities, total: activities.length })
}

// POST /api/activities
export async function POST(req: NextRequest) {
  const body = await req.json()
  const { studentId, category, title, description, rating, recordedBy = 'system', date } = body
  if (!studentId || !category || !title) {
    return NextResponse.json({ error: 'studentId, category, title required' }, { status: 400 })
  }
  const activity = await db.dailyActivity.create({
    data: {
      studentId,
      category,
      title,
      description: description ?? '',
      rating: rating ?? null,
      recordedBy,
      date: date ? new Date(date) : new Date(),
    },
  })
  return NextResponse.json({ activity })
}
