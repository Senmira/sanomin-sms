import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  const staff = await db.staff.findMany({ orderBy: { role: 'asc' } })
  return NextResponse.json({ staff })
}
