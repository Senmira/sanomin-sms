import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

// GET /api/dashboard/metrics — aggregates for the Admin Dashboard
export async function GET() {
  const [students, todayAttendance, fees, programs, healthAlerts, staff] = await Promise.all([
    db.student.findMany({ select: { id: true, status: true, ageGroup: true, gender: true, religion: true } }),
    db.attendanceLog.findMany({
      where: { date: { gte: todayStart(), lt: tomorrowStart() } },
      include: { student: { select: { id: true, fullName: true, ageGroup: true, studentCode: true } } },
    }),
    db.fee.findMany({ select: { amount: true, paidAmount: true, status: true, period: true } }),
    db.program.findMany({ include: { enrollments: true } }),
    db.healthAlert.findMany({ where: { active: true }, select: { id: true, severity: true, type: true, studentId: true } }),
    db.staff.findMany({ select: { id: true, role: true, active: true } }),
  ])

  const totalStudents = students.length
  const activeStudents = students.filter((s) => s.status === 'ACTIVE').length

  const checkedInToday = todayAttendance.filter((l) => l.checkInTime).length
  const checkedOutToday = todayAttendance.filter((l) => l.checkOutTime).length
  const absentToday = todayAttendance.filter((l) => l.status === 'ABSENT').length
  const stillInCare = todayAttendance.filter((l) => l.checkInTime && !l.checkOutTime).length

  const totalFees = fees.reduce((s, f) => s + f.amount, 0)
  const collectedFees = fees.reduce((s, f) => s + f.paidAmount, 0)
  const pendingFees = totalFees - collectedFees
  const overdueFees = fees.filter((f) => f.status === 'OVERDUE').reduce((s, f) => s + (f.amount - f.paidAmount), 0)
  const pendingPaymentsCount = fees.filter((f) => f.status === 'PENDING' || f.status === 'PARTIAL' || f.status === 'OVERDUE').length

  // Age group distribution
  const ageGroupCounts: Record<string, number> = {}
  for (const s of students) {
    ageGroupCounts[s.ageGroup] = (ageGroupCounts[s.ageGroup] ?? 0) + 1
  }

  // Gender distribution
  const genderCounts: Record<string, number> = {}
  for (const s of students) genderCounts[s.gender] = (genderCounts[s.gender] ?? 0) + 1

  // Religion distribution
  const religionCounts: Record<string, number> = {}
  for (const s of students) religionCounts[s.religion] = (religionCounts[s.religion] ?? 0) + 1

  // Program enrolment counts
  const programCounts = programs.map((p) => ({
    code: p.code,
    name: p.name,
    color: p.color,
    count: p.enrollments.length,
    capacity: p.capacity,
  }))

  // Today's check-in roster
  const todayRoster = todayAttendance.map((l) => ({
    id: l.id,
    studentId: l.studentId,
    studentName: l.student.fullName,
    studentCode: l.student.studentCode,
    ageGroup: l.student.ageGroup,
    status: l.status,
    checkInTime: l.checkInTime,
    checkOutTime: l.checkOutTime,
    method: l.method,
  }))

  // Health alerts by severity
  const healthBySeverity: Record<string, number> = { HIGH: 0, MEDIUM: 0, LOW: 0 }
  for (const h of healthAlerts) healthBySeverity[h.severity] = (healthBySeverity[h.severity] ?? 0) + 1

  return NextResponse.json({
    totals: {
      totalStudents,
      activeStudents,
      checkedInToday,
      checkedOutToday,
      stillInCare,
      absentToday,
      pendingPaymentsCount,
      totalFees,
      collectedFees,
      pendingFees,
      overdueFees,
      activeHealthAlerts: healthAlerts.length,
      staffCount: staff.filter((s) => s.active).length,
    },
    distributions: {
      ageGroups: ageGroupCounts,
      genders: genderCounts,
      religions: religionCounts,
      programs: programCounts,
      healthBySeverity,
    },
    todayRoster,
    generatedAt: new Date().toISOString(),
  })
}

function todayStart() { const d = new Date(); d.setHours(0, 0, 0, 0); return d }
function tomorrowStart() { const d = todayStart(); d.setDate(d.getDate() + 1); return d }
