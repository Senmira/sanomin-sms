// Lightweight API client for the Preschool Student Management System.
// All routes use relative paths under /api/* — that's all the gateway allows.

import type {
  Student, AttendanceLog, Fee, DashboardMetrics, ProgramEnriched, Staff, DailyActivity,
} from './types'

async function getJSON<T>(url: string): Promise<T> {
  const res = await fetch(url, { cache: 'no-store' })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error((err as any).error ?? `Request failed: ${res.status}`)
  }
  return res.json() as Promise<T>
}

async function postJSON<T>(url: string, body: unknown): Promise<T> {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error((err as any).error ?? `Request failed: ${res.status}`)
  }
  return res.json() as Promise<T>
}

async function patchJSON<T>(url: string, body: unknown): Promise<T> {
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error((err as any).error ?? `Request failed: ${res.status}`)
  }
  return res.json() as Promise<T>
}

export const api = {
  // Dashboard
  getDashboard: () => getJSON<DashboardMetrics>('/api/dashboard/metrics'),

  // Students
  listStudents: (params: Record<string, string | undefined> = {}) => {
    const q = new URLSearchParams()
    for (const [k, v] of Object.entries(params)) if (v) q.set(k, v)
    return getJSON<{ students: Student[]; total: number }>(`/api/students?${q.toString()}`)
  },
  getStudent: (id: string) => getJSON<{ student: Student & { attendance: AttendanceLog[]; fees: Fee[]; activities: DailyActivity[]; healthAlerts: any[] } }>(`/api/students/${id}`),
  updateStudent: (id: string, patch: Partial<Student>) => patchJSON<{ student: Student }>(`/api/students/${id}`, patch),

  // Attendance
  getAttendance: (params: Record<string, string | undefined> = {}) => {
    const q = new URLSearchParams()
    for (const [k, v] of Object.entries(params)) if (v) q.set(k, v)
    return getJSON<{ logs: AttendanceLog[]; total: number }>(`/api/attendance?${q.toString()}`)
  },
  checkIn:   (studentId: string, method = 'KIOSK', recordedBy = 'system') => postJSON<{ log: AttendanceLog }>('/api/attendance', { studentId, action: 'checkIn', method, recordedBy }),
  checkOut:  (studentId: string, recordedBy = 'system') => postJSON<{ log: AttendanceLog }>('/api/attendance', { studentId, action: 'checkOut', recordedBy }),
  markAbsent:(studentId: string, recordedBy = 'system') => postJSON<{ log: AttendanceLog }>('/api/attendance', { studentId, action: 'markAbsent', recordedBy }),

  // Fees
  listFees: (params: Record<string, string | undefined> = {}) => {
    const q = new URLSearchParams()
    for (const [k, v] of Object.entries(params)) if (v) q.set(k, v)
    return getJSON<{ fees: Fee[]; total: number }>(`/api/fees?${q.toString()}`)
  },
  recordPayment: (feeId: string, amount: number, method = 'CASH') => postJSON<{ fee: Fee }>('/api/fees', { feeId, amount, method }),

  // Programs
  listPrograms: () => getJSON<{ programs: ProgramEnriched[] }>('/api/programs'),

  // Staff
  listStaff: () => getJSON<{ staff: Staff[] }>('/api/staff'),

  // Activities
  listActivities: (studentId?: string, limit = 50) => getJSON<{ activities: DailyActivity[]; total: number }>(`/api/activities?studentId=${studentId ?? ''}&limit=${limit}`),
}

// ---------- formatting helpers ----------
export function fmtLKR(n: number): string {
  return new Intl.NumberFormat('en-LK', { style: 'currency', currency: 'LKR', maximumFractionDigits: 0 }).format(n)
}

export function fmtDate(d?: string | Date | null): string {
  if (!d) return '—'
  const dt = typeof d === 'string' ? new Date(d) : d
  return dt.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
}

export function fmtTime(d?: string | Date | null): string {
  if (!d) return '—'
  const dt = typeof d === 'string' ? new Date(d) : d
  return dt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false })
}

export function fmtDateTime(d?: string | Date | null): string {
  if (!d) return '—'
  return `${fmtDate(d)} ${fmtTime(d)}`
}

export function calcAge(dob: string | Date): string {
  const d = typeof dob === 'string' ? new Date(dob) : dob
  const now = new Date()
  let years = now.getFullYear() - d.getFullYear()
  let months = now.getMonth() - d.getMonth()
  if (months < 0) { years--; months += 12 }
  if (years < 0) return '—'
  return months === 0 ? `${years}y` : `${years}y ${months}m`
}
