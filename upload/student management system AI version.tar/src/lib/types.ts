// Shared types for the Preschool Student Management System

export type Role = 'ADMIN' | 'TEACHER' | 'FINANCE' | 'KIOSK'

export interface Program {
  id: string
  code: string
  name: string
  description: string
  monthlyFee: number
  capacity: number
  color: string
  createdAt: string
  updatedAt: string
}

export interface Guardian {
  id: string
  name: string
  phone: string
  email?: string | null
  address: string
  relationship: string
  emergencyContact: boolean
}

export interface Enrollment {
  id: string
  programId: string
  program: Program
  status: string
  enrolledOn: string
}

export interface Student {
  id: string
  studentCode: string
  indexNo: string
  fullName: string
  gender: string
  dob: string
  admissionDate: string
  ageGroup: string
  religion: string
  nationality: string
  previousSchool: string
  photoUrl?: string | null
  status: string
  notes: string
  guardians?: Guardian[]
  enrollments?: Enrollment[]
}

export interface AttendanceLog {
  id: string
  studentId: string
  date: string
  checkInTime?: string | null
  checkOutTime?: string | null
  method: string
  status: string
  notes?: string | null
  recordedBy: string
  student?: {
    id: string
    fullName: string
    studentCode: string
    ageGroup: string
  }
}

export interface Fee {
  id: string
  studentId: string
  programId?: string | null
  amount: number
  paidAmount: number
  currency: string
  period: string
  dueDate: string
  status: string
  method?: string | null
  paidAt?: string | null
  notes?: string | null
  student?: Student
  program?: Program | null
}

export interface DailyActivity {
  id: string
  studentId: string
  date: string
  category: string
  title: string
  description?: string | null
  rating?: number | null
  recordedBy: string
}

export interface HealthAlert {
  id: string
  studentId: string
  type: string
  severity: string
  description: string
  active: boolean
}

export interface Staff {
  id: string
  staffCode: string
  name: string
  email: string
  phone?: string | null
  role: Role
  assignedClass?: string | null
  assignedPrograms: string
  active: boolean
}

export interface DashboardMetrics {
  totals: {
    totalStudents: number
    activeStudents: number
    checkedInToday: number
    checkedOutToday: number
    stillInCare: number
    absentToday: number
    pendingPaymentsCount: number
    totalFees: number
    collectedFees: number
    pendingFees: number
    overdueFees: number
    activeHealthAlerts: number
    staffCount: number
  }
  distributions: {
    ageGroups: Record<string, number>
    genders: Record<string, number>
    religions: Record<string, number>
    programs: { code: string; name: string; color: string; count: number; capacity: number }[]
    healthBySeverity: Record<string, number>
  }
  todayRoster: {
    id: string
    studentId: string
    studentName: string
    studentCode: string
    ageGroup: string
    status: string
    checkInTime?: string | null
    checkOutTime?: string | null
    method: string
  }[]
  generatedAt: string
}

export interface ProgramEnriched {
  id: string
  code: string
  name: string
  description: string
  monthlyFee: number
  capacity: number
  color: string
  enrolledCount: number
  capacityLeft: number
  revenueCollected: number
  revenuePending: number
  students?: Pick<Student, 'id' | 'fullName' | 'ageGroup' | 'gender' | 'studentCode'>[]
}

// ----- Role-based access control -----
export const NAV_ITEMS = [
  { key: 'dashboard',  label: 'Dashboard',         roles: ['ADMIN', 'TEACHER', 'FINANCE'] as Role[], icon: 'LayoutDashboard' },
  { key: 'students',   label: 'Students',          roles: ['ADMIN', 'TEACHER', 'FINANCE'] as Role[], icon: 'Users' },
  { key: 'checkin',    label: 'Check-In / Out',    roles: ['ADMIN', 'TEACHER', 'KIOSK']   as Role[], icon: 'DoorOpen' },
  { key: 'attendance', label: 'Attendance History',roles: ['ADMIN', 'TEACHER']            as Role[], icon: 'CalendarDays' },
  { key: 'fees',       label: 'Fees & Billing',    roles: ['ADMIN', 'FINANCE']            as Role[], icon: 'CreditCard' },
  { key: 'programs',   label: 'Programs',           roles: ['ADMIN', 'TEACHER', 'FINANCE'] as Role[], icon: 'Boxes' },
] as const

export type NavKey = (typeof NAV_ITEMS)[number]['key']

export function navForRole(role: Role): { key: NavKey; label: string; icon: string }[] {
  return NAV_ITEMS.filter((n) => n.roles.includes(role)).map((n) => ({ key: n.key, label: n.label, icon: n.icon }))
}

export const ROLE_LABELS: Record<Role, string> = {
  ADMIN:   'Administrator',
  TEACHER: 'Teacher',
  FINANCE: 'Finance',
  KIOSK:   'Kiosk',
}

export const ROLE_STAFF: Record<Role, { code: string; name: string; class?: string }> = {
  ADMIN:   { code: 'A001', name: 'Anjali Perera' },
  TEACHER: { code: 'T002', name: 'Nadeesha Fernando', class: '3-4' },
  FINANCE: { code: 'F001', name: 'Saman Bandara' },
  KIOSK:   { code: 'K001', name: 'Kiosk Console' },
}
